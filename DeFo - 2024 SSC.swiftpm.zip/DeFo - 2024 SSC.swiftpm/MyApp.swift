
// This is the starting point of the application.
import SwiftUI

@main
struct MyApp: App {
    var body: some Scene {
        WindowGroup {
            MainTabView()
        }
    }
}
