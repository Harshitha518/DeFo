import SwiftUI
// Application background colors are defined here.
struct AppColor {
    static let main = Color(.sRGB, red: 0, green: 0.8, blue: 0.2, opacity: 0.2)
    static let sky = Color(.sRGB, red:0, green: 0.2, blue: 0.8, opacity: 0.2)
}
